//
//  jobview.swift
//  api-persona
//
//  Created by iOS Lab on 28/03/23.
//

import Foundation
import SwiftUI

struct jobview: View {
    let job: Job
    var body: some View{
        VStack(alignment: .leading, spacing: 10){
            HStack{
                Text(job.title)
                    .font(.title)
                    .font(.headline)
                    .bold()
                Spacer()
                Image(systemName: "person.crop.circle")
                    .resizable().scaledToFit()
                    .frame(width: 85, height: 60)
            }
            Text(job.company)
                .bold()
            Text(job.location)
            Divider()
            HStack{
               
                Text(job.description)
            }
            VStack{
               
                Text("Requirements:")
                ForEach(job.requirements, id: \.self) { requirement
                    in
                    Text("•\(requirement)")
                                                                        
                }.padding()
                
                
            }
            HStack{
                Text("$\(job.salary.formatted())")
            }
            
        }.padding()
        
        
        }
    }
    

