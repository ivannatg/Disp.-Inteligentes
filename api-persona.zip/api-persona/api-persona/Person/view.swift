//
//  view.swift
//  api-persona
//
//  Created by iOS Lab on 23/03/23.
//

import Foundation
import SwiftUI

struct PersonView: View {
    let person: Person
    var body: some View{
        VStack(alignment: .leading, spacing: 10){
            HStack{
                Text(person.name)
                    .font(.title)
                    .font(.headline)
                    .bold()
                Spacer()
                Image(systemName: "person.crop.circle")
                    .resizable().scaledToFit()
                    .frame(width: 85, height: 60)
            }
            Text(person.username)
                .bold()
            Text(person.company.name)
            Divider()
            HStack{
                Image(systemName: "envelope")
                Text(person.email)
            }
            HStack{
                Image(systemName: "phone")
                Text(person.phone)
            }
            HStack{
                Image(systemName: "globe")
                Text(person.website)
            }
            
        }.padding()
        
        NavigationLink(destination: AddressView(Address: person.address)) {
            Text("View Address")
                .font(.headline)
                .foregroundColor(.white)
                .padding()
                .frame(maxWidth: .infinity)
                .background(Color.blue)
            
        }
        
        
        }
    }
    

