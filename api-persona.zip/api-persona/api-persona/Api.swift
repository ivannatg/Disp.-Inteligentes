//
//  Api.swift
//  api-persona
//
//  Created by iOS Lab on 23/03/23.
//

import Foundation

class Api {
    func getPeople(completion: @escaping([Person]) -> ()) {
        guard let url = URL(string: "https://jsonplaceholder.typicode.com/users") else { return }
        URLSession.shared.dataTask(with: url) { (data, _, _) in
            let people = try! JSONDecoder().decode([Person].self, from: data!)
            completion(people)
        }.resume()
    }
}





//guard es para que lo identifique y si no que detenga la funcion
//funcion que se va correr es el completion, y el escaping sirve para que la funcion viva despues de correr todo el codigo.
