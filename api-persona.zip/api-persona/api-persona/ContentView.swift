//
//  ContentView.swift
//  api-persona
//
//  Created by iOS Lab on 23/03/23.
//

import SwiftUI

struct ContentView: View {
    
    //    people esta en un arreglo de personas
    
    @State private var people: [Person] = []
    @State private var path = NavigationPath()
    
    
    var body: some View {
        NavigationStack(path: $path){
            VStack {
                List(people) { person in
                    NavigationLink(person.name, value: person)
                    
                } .onAppear(){
                    Api().getPeople{ people in
                        self.people = people
                    }
                }.navigationDestination(for: Person.self){
                    person in PersonView(person:  person)
                }
                Section("Jobs") {
                    List(Job.jobs) { job in NavigationLink(job.title, value: job)}
                }.navigationDestination(for: Job.self){
                    job in jobview(job: job)
                }
                
            }
        }
    }
}
    
    
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            ContentView()
        }
    }

