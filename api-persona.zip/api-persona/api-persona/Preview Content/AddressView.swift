//
//  AddressView.swift
//  api-persona
//
//  Created by iOS Lab on 28/03/23.
//

import Foundation
import SwiftUI

struct AddressView: View {
    let Address: Address
    var body: some View{
        VStack(alignment: .leading, spacing: 10){
            HStack{
                Text("Address")
                    .font(.title)
                    .font(.headline)
                    .bold()
                Spacer()
            }
            Divider()
            HStack{
                Image(systemName: "location")
                Text("\(Address.street), \(Address.suite)")
            }
            HStack{
                Image(systemName: "city")
                Text("\(Address.city), \(Address.zipcode)")
            }
            HStack{
                Image(systemName: "globe")
                Text("Latitude: \(Address.geo.lat), Longitud: \(Address.geo.lng)")
            }.padding()
            
            Spacer()
            
        }
    }
    
}
