//
//  api_personaApp.swift
//  api-persona
//
//  Created by iOS Lab on 23/03/23.
//

import SwiftUI

@main
struct api_personaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
