//
//  todolistApp.swift
//  todolist
//
//  Created by iOS Lab on 25/04/23.
//

import SwiftUI

@main
struct todolistApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
