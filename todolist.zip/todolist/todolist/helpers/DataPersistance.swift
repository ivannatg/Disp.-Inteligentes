//
//  DataPersistance.swift
//  todolist
//
//  Created by iOS Lab on 27/04/23.
//

import Foundation

class DataPersistance {
    private let fileManager = FileManager.default
    private let documentsDirectory: URL
    private let itemsURL: URL
    
    init() {
        self.documentsDirectory = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first!
        //sobre esta ruta "user/ivanna/todo/ crea el item y le agrega el json items.json"
        self.itemsURL = documentsDirectory.appendingPathComponent("items").appendingPathExtension("json")
    }
    
    func saveItems(items: [ItemModel]) throws {
        let encoder = JSONEncoder()
        let encodedItems = try encoder.encode(items)
        try encodedItems.write(to: itemsURL)
    }
  // va a entrar a la parte de abajo del codigo si tiene algo guardado
    func loadItems() throws -> [ItemModel] {
        guard fileManager.fileExists(atPath: itemsURL.path) else {
            return []
        }
        
        let decoder = JSONDecoder()
        let data = try Data(contentsOf: itemsURL)
        let decodedItems = try decoder.decode([ItemModel].self, from: data)
        return decodedItems
    }
    
}
